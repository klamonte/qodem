The Telnet/Dial-Up BBS Guide - March 2021
-----------------------------------------

Featured BBSes now on our website and Facebook

It seems with a large number of BBSes that some don't get
enough recognition (and traffic) that they deserve. We
started this in February 2021 and will continue to 
have several "Featured BBSes" that I will showcase
here, on the main list, and on our Facebook page.

Distro List for Telnet BBS Guide moved to Groups.io

As of February 2019, the monthly distribution list
of the Telnet BBS Guide has moved to Groups.io. If
you wish to subscribe to the new mailing list, please
sign up at the following location:

https://groups.io/g/telnetbbsguide/

Please note that if you subscribed to to the old 
Yahoo group, your subscription will NOT carry over
to the new list. You must sign up on the new site
in order to continue to receive the monthly
distribution of the list.

Notes for BBS Sysops:

We are aware that some of you are moving your BBSes to a non-
standard port from the default telnet port number (23). If you
do move to a non-standard port, please either update your listing
or let us know and we'll update your listing for you. Remember,
we do verify your BBS listing several times a month. If it is not in
operation, we will mark it down. We will wait for 30 days.
If it's still down, we will delete it from the database. So,
please keep your listing updated if you do indeed make
any address changes. Thanks!

And of course, if your listing is already there, please "claim"
your listing. Add an account and then claim it. I will allow you
to edit your own listing. DO NOT create a new listing if your
BBS already exists. That makes more work for me!

Finally, when you sign up as a new user to either add or edit
your BBS listing, please enter your first or last name in the
signup information. Otherwise your listing may not be accepted.
Thanks!

Thanks, and continue to enjoy the ride!

- Dave

The Telnet BBS Guide
https://www.telnetbbsguide.com

The BBS Corner
http://www.bbscorner.com

Monthly Distribution of the Telnet BBS Guide
https://groups.io/g/telnetbbsguide/

Facebook Discussion Group
https://www.facebook.com/groups/bbscorner

Diamond Mine Online BBS
http://www.dmine.com (info) & http://www.dmine.net (BBS access)
telnet://bbs.dmine.net:24

